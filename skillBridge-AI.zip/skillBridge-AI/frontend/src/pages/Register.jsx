import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";


function Register(){

    const [name,setName]=useState("");
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");

    const navigate = useNavigate();



    const handleRegister = async(e)=>{

        e.preventDefault();


        try{

            await API.post(
                "/users/register",
                {
                    name,
                    email,
                    password
                }
            );


            alert("Register Success");

            navigate("/");


        }
        catch(error){

            alert("Register Failed");

        }

    };


    return(

        <div>

            <h2>
                Register
            </h2>


            <form onSubmit={handleRegister}>


                <input
                placeholder="Name"
                onChange={(e)=>setName(e.target.value)}
                />


                <input
                placeholder="Email"
                onChange={(e)=>setEmail(e.target.value)}
                />


                <input
                type="password"
                placeholder="Password"
                onChange={(e)=>setPassword(e.target.value)}
                />


                <button>
                    Register
                </button>


            </form>


        </div>

    );

}


export default Register;