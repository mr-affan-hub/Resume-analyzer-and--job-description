import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

import Navbar from "../components/Navbar";
import API from "../services/api";


function Dashboard() {

  const navigate = useNavigate();

  const [dashboardData, setDashboardData] = useState(null);


  useEffect(() => {

    const fetchDashboard = async () => {

      try {

        const response = await API.get("/dashboard/");

        setDashboardData(response.data);

      } catch (error) {

        console.log(
          "Dashboard Error:",
          error.response?.data
        );

      }

    };


    fetchDashboard();

  }, []);



  return (
    <>

      <Navbar />


      <div className="dashboard">

        <h1>🚀 SkillBridge AI Dashboard</h1>


        <p>
          Upload your resume and get AI-powered analysis,
          resume score, missing skills, and job recommendations.
        </p>


        <button
          onClick={() => navigate("/upload")}
        >
          📤 Upload Resume
        </button>



        <div className="cards">


          <div className="card">

            <h2>📄 Resume Score</h2>

            <h3>
              {dashboardData?.average_score || 0} / 100
            </h3>

          </div>



          <div className="card">

            <h2>🧠 Skills</h2>

            <p>
              Resume skills will appear here
            </p>

          </div>



          <div className="card">

            <h2>⚠️ Missing Skills</h2>

            <p>
              AI will suggest missing skills
            </p>

          </div>



          <div className="card">

            <h2>💼 Recommended Job</h2>

            <p>
              {
                dashboardData?.latest_resume?.recommended_job
                || "Upload resume to get recommendation"
              }
            </p>

          </div>


        </div>


      </div>


    </>
  );
}


export default Dashboard;