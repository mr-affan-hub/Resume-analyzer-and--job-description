import { useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";

function Login() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const navigate = useNavigate();


    const handleLogin = async (e) => {

        e.preventDefault();

        try {

            const response = await API.post(
                "/users/login",
                {
                    email,
                    password
                }
            );


            localStorage.setItem(
                "token",
                response.data.access_token
            );


            alert("Login Successful ✅");

            navigate("/dashboard");


        } catch (error) {

            console.log(
                "LOGIN ERROR:",
                error.response?.data
            );


            alert(
                error.response?.data?.detail ||
                "Login Failed"
            );

        }

    };


    return (

        <div>

            <h2>
                SkillBridge AI Login
            </h2>


            <form onSubmit={handleLogin}>


                <input
                    type="email"
                    placeholder="Enter Email"
                    value={email}
                    onChange={(e) =>
                        setEmail(e.target.value)
                    }
                    required
                />


                <br />


                <input
                    type="password"
                    placeholder="Enter Password"
                    value={password}
                    onChange={(e) =>
                        setPassword(e.target.value)
                    }
                    required
                />


                <br />


                <button type="submit">
                    Login
                </button>


            </form>


        </div>

    );

}


export default Login;