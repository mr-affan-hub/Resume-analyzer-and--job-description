function Home() {
  return (
    <div>
      <h1>SkillBridge AI</h1>
      <p>AI Resume Analyzer Platform</p>
    </div>
  );
}

export default Home;