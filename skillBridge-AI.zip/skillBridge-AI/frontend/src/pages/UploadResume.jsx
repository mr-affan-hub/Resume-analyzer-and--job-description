import { useState } from "react";
import API from "../services/api";
import Navbar from "../components/Navbar";


function UploadResume() {

  const [file, setFile] = useState(null);
  const [message, setMessage] = useState("");


  const uploadResume = async () => {

    if (!file) {
      setMessage("Please select resume");
      return;
    }


    const formData = new FormData();

    formData.append("file", file);


    try {

      const response = await API.post(
        "/resume/upload",
        formData,
        {
          headers:{
            "Content-Type":"multipart/form-data"
          }
        }
      );


      console.log(response.data);

      setMessage("Resume uploaded successfully ✅");


    } catch(error){

      console.log(error);

      setMessage("Upload failed ❌");

    }

  };


  return (

    <>

    <Navbar />

    <div className="dashboard">

      <h1>📄 Upload Resume</h1>


      <input
        type="file"
        accept=".pdf,.docx"
        onChange={(e)=>setFile(e.target.files[0])}
      />


      <br/><br/>


      <button onClick={uploadResume}>
        Upload Resume
      </button>


      <h3>
        {message}
      </h3>


    </div>


    </>

  );

}


export default UploadResume;