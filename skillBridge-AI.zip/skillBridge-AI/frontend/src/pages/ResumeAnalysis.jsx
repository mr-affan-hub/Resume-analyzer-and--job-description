import { useEffect, useState, useContext } from "react";

import Navbar from "../components/Navbar";
import api from "../services/api";

import { ResumeContext } from "../context/ResumeContext";


function ResumeAnalysis(){

    const { result } = useContext(ResumeContext);

    const [analysis, setAnalysis] = useState(null);
    const [loading, setLoading] = useState(true);



 useEffect(() => {

    const getAnalysis = async () => {

        try {

            const resumeId =
                result?.resume_id ||
                localStorage.getItem("resume_id");

            console.log("Context:", result);
            console.log("LocalStorage:", localStorage.getItem("resume_id"));
            console.log("ResumeId:", resumeId);

            if (!resumeId) {

                console.log("Resume ID missing");
                setLoading(false);
                return;

            }


            const response = await api.post(
    `/resume/gemini/${resumeId}`
);

console.log("AI Result:", response.data);

if (!response.data || !response.data.analysis) {
    console.log("No analysis received from backend");
    return;
}

const aiAnalysis = response.data.analysis;

console.log("Analysis:", aiAnalysis);
console.log("Score:", aiAnalysis.score);
console.log("Feedback:", aiAnalysis.feedback);
console.log("Suggestions:", aiAnalysis.suggestions);
console.log("Strengths:", aiAnalysis.strengths);
console.log("Weaknesses:", aiAnalysis.weaknesses);

setAnalysis(aiAnalysis);
        }
        catch (error) {

            console.log(
                "Analysis Error:",
                error.response?.data || error.message
            );

        }
        finally {

            setLoading(false);

        }

    };

    getAnalysis();

}, [result]);





    return(

        <>

        <Navbar/>


        <div className="dashboard">


            <h1>
                🤖 AI Resume Analysis
            </h1>



            {
                loading ?


                (

                    <h3>
                        Analyzing Resume... ⏳
                    </h3>

                )


                :


                analysis ?


                (

                    <div className="cards">


                        <div className="card">

                            <h2>
                                📊 Resume Score
                            </h2>


                            <h1>

                                {
                                    analysis.score
                                    ||
                                    "No Score"
                                }

                                /100

                            </h1>


                        </div>





                        <div className="card">


                            <h2>
                                📝 Feedback
                            </h2>


                            <p>

                                {
                                    analysis.feedback
                                    ||
                                    analysis.result
                                    ||
                                    "No feedback available"
                                }

                            </p>


                        </div>





                        <div className="card">


                            <h2>
                                ✅ Suggestions
                            </h2>


                            {

                                Array.isArray(
                                    analysis.suggestions
                                )

                                ?

                                (

                                    <ul>

                                    {

                                        analysis.suggestions.map(
                                            (item,index)=>(

                                                <li key={index}>
                                                    {item}
                                                </li>

                                            )

                                        )

                                    }

                                    </ul>

                                )


                                :

                                (

                                    <p>
                                        {
                                            JSON.stringify(
                                                analysis.suggestions
                                            )
                                        }
                                    </p>

                                )

                            }


                        </div>





                        <div className="card">


                            <h2>
                                💪 Strengths
                            </h2>


                            {
    Array.isArray(analysis.strengths)
    ?
    (
        <ul>
            {
                analysis.strengths.map(
                    (item,index)=>(
                        <li key={index}>
                            {item}
                        </li>
                    )
                )
            }
        </ul>
    )
    :
    (
        <p>{analysis.strengths}</p>
    )
}


                        </div>





                        <div className="card">


                            <h2>
                                ⚠️ Weakness
                            </h2>


                            {
    Array.isArray(analysis.weaknesses)
    ?
    (
        <ul>
            {
                analysis.weaknesses.map(
                    (item,index)=>(
                        <li key={index}>
                            {item}
                        </li>
                    )
                )
            }
        </ul>
    )
    :
    (
        <p>{analysis.weaknesses}</p>
    )
}


                        </div>



                    </div>

                )


                :


                (

                    <h3>
                        Upload resume to get AI analysis
                    </h3>

                )


            }



        </div>


        </>

    );

}


export default ResumeAnalysis;