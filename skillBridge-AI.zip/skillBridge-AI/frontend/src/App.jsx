import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import { ResumeProvider } from "./context/ResumeContext";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import ResumeUpload from "./components/ResumeUpload";
import ResumeAnalysis from "./pages/ResumeAnalysis";

function App() {
  return (
    <ResumeProvider>
      <BrowserRouter>
        <Routes>

          <Route path="/" element={<Login />} />

          <Route path="/register" element={<Register />} />

          <Route path="/dashboard" element={<Dashboard />} />

          <Route path="/upload" element={<ResumeUpload />} />

          <Route path="/analysis" element={<ResumeAnalysis />} />

        </Routes>
      </BrowserRouter>
    </ResumeProvider>
  );
}

export default App;