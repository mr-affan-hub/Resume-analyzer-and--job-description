import { createContext, useState } from "react";

export const ResumeContext = createContext();

export function ResumeProvider({ children }) {
  const [result, setResult] = useState(null);

  return (
    <ResumeContext.Provider value={{ result, setResult }}>
      {children}
    </ResumeContext.Provider>
  );
}