function ResultCard({ result }) {
  if (!result) return null;

  return (
    <div className="result-card">
      <h2>Resume Analysis Result</h2>

      <p><strong>Name:</strong> {result.name}</p>
      <p><strong>Email:</strong> {result.email}</p>
      <p><strong>Phone:</strong> {result.phone}</p>

      <h3>Resume Score</h3>
      <h1>{result.resume_score}/100</h1>

      <h3>Skills</h3>
      <div>
        {result.skills?.map((skill, index) => (
          <span key={index} className="badge">
            {skill}
          </span>
        ))}
      </div>

      <h3>Missing Skills</h3>
      <div>
        {result.missing_skills?.map((skill, index) => (
          <span key={index} className="missing">
            {skill}
          </span>
        ))}
      </div>

      <h3>Recommended Job</h3>
      <p>{result.recommended_job}</p>
    </div>
  );
}

export default ResultCard;