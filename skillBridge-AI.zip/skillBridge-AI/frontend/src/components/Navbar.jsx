import { Link } from "react-router-dom";


function Navbar() {

  return (
    <nav>

      <h2>SkillBridge AI</h2>

      <div>
        <Link to="/dashboard">
          Dashboard
        </Link>

        <Link to="/analysis">
          Resume Analysis
        </Link>

        <Link to="/">
          Logout
        </Link>
      </div>

    </nav>
  );
}


export default Navbar;