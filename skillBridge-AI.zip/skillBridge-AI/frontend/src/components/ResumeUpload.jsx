import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";

import api from "../services/api";
import { ResumeContext } from "../context/ResumeContext";

import Navbar from "./Navbar";


function ResumeUpload() {

  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);

  const { setResult } = useContext(ResumeContext);

  const navigate = useNavigate();



  const handleUpload = async () => {

    if (!file) {

      alert("Please select a PDF resume.");

      return;

    }


    const formData = new FormData();

    formData.append("file", file);



    try {

      setLoading(true);



      const response = await api.post(
        "/resume/upload",
        formData,
        {
          headers:{
            "Content-Type":"multipart/form-data",
          },
        }
      );



        setResult(response.data);


      // Save resume id for analysis page
      localStorage.setItem(
        "resume_id",
        response.data.resume_id
      );


      console.log(
        "Upload Response:",
        response.data
      );

      alert(
        "Resume uploaded successfully ✅"
      );



      navigate("/analysis");



    } catch(error){


      console.error(
        "Upload Error:",
        error.response?.data || error.message
      );


      alert(
        "Resume upload failed ❌"
      );



    } finally {

      setLoading(false);

    }

  };



  return (

    <>

    <Navbar />


    <div className="dashboard">


      <h1>
        📄 Upload Resume
      </h1>



      <input

        type="file"

        accept=".pdf"

        onChange={(e)=>
          setFile(e.target.files[0])
        }

      />


      {
        file && (

          <p>
            Selected: {file.name}
          </p>

        )
      }



      <br/><br/>


      <button

        onClick={handleUpload}

        disabled={loading}

      >

        {
          loading
          ? "Uploading..."
          : "Upload Resume"
        }


      </button>



    </div>


    </>

  );

}


export default ResumeUpload;