function ResumeCard({ resume }) {

  return (
    <div>

      <h3>
        {resume.filename}
      </h3>

      <p>
        Score: {resume.score}%
      </p>

      <p>
        Job:
        {resume.recommended_job}
      </p>

      <p>
        Skills:
        {resume.skills}
      </p>

    </div>
  );
}


export default ResumeCard;