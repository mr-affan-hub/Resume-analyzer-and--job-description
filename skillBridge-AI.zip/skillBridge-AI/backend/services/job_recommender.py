def recommend_job(skills):

    skills = [skill.lower() for skill in skills]

    if "python" in skills and "fastapi" in skills:
        return "Backend Developer"

    elif "python" in skills and "machine learning" in skills:
        return "Machine Learning Engineer"

    elif "python" in skills and "power bi" in skills:
        return "Data Analyst"

    elif "react" in skills and "javascript" in skills:
        return "Frontend Developer"

    elif "java" in skills:
        return "Java Developer"

    else:
        return "Software Developer"