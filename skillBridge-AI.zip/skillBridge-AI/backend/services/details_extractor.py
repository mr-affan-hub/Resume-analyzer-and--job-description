import re


def extract_email(text):
    match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
    return match.group(0) if match else ""


def extract_phone(text):
    match = re.search(r'(\+91[- ]?)?[6-9]\d{9}', text)
    return match.group(0) if match else ""


def extract_name(text):
    lines = text.split("\n")

    ignore_words = [
        "KEY SKILLS",
        "PROFILE SUMMARY",
        "EDUCATION",
        "PROJECTS",
        "EXPERIENCE",
        "LANGUAGES",
        "CERTIFICATIONS",
        "SKILLS",
        "OBJECTIVE",
        "RESUME"
    ]

    for line in lines:
        line = line.strip()

        if (
            len(line.split()) >= 2
            and len(line.split()) <= 4
            and "@" not in line
            and not re.search(r"\d", line)
            and line.upper() not in ignore_words
        ):
            return line

    return ""


def extract_details(text):
    return {
        "name": extract_name(text),
        "email": extract_email(text),
        "phone": extract_phone(text)
    }


def extract_skills(text):
    skills_db = [
        "Python",
        "Java",
        "C",
        "C++",
        "SQL",
        "HTML",
        "CSS",
        "JavaScript",
        "React",
        "FastAPI",
        "Django",
        "Flask",
        "Machine Learning",
        "Deep Learning",
        "Data Analytics",
        "Power BI",
        "Excel",
        "Git",
        "GitHub",
        "AWS",
        "MS Word",
        "PowerPoint",
        "Communication Skills",
        "Leadership",
        "Team Management",
        "Adaptability"
    ]

    found_skills = []

    for skill in skills_db:
        if skill.lower() in text.lower():
            found_skills.append(skill)

    return found_skills