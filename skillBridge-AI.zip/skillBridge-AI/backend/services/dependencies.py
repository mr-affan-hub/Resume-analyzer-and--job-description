from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from services.jwt_handler import verify_token

security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    try:
        token = credentials.credentials

        print("TOKEN RECEIVED:", token)

        payload = verify_token(token)

        print("TOKEN PAYLOAD:", payload)

        user_id = payload.get("sub")

        if user_id is None:
            raise Exception("sub missing")

        return int(user_id)

    except Exception as e:
        print("JWT ERROR:", e)

        raise HTTPException(
            status_code=401,
            detail="Invalid token"
        )