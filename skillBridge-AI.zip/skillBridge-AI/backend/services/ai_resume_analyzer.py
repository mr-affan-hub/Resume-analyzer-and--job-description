import google.generativeai as genai

# Paste your NEW Gemini API Key here
GEMINI_API_KEY = "AQ.Ab8RN6LvqudH3ZgJU7ipeHxBfxMroiSb3Jy8vFHfrmqJ-gxpQw"

genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel("gemini-2.5-flash-lite")


def analyze_resume(resume_text: str):

    prompt = f"""
You are an ATS Resume Expert.

Analyze the following resume.

Return:
1. Overall Resume Score (0-100)
2. Strengths
3. Weaknesses
4. Missing Skills
5. Improvement Suggestions
6. Recommended Job Roles

Resume:
{resume_text}
"""

    response = model.generate_content(prompt)

    return response.text