def calculate_match(resume_skills, job_skills):
    """
    Compare resume skills with job skills and calculate match percentage.
    """

    # Convert resume skills to lowercase
    resume_set = {
        skill.strip().lower()
        for skill in resume_skills
        if skill.strip()
    }

    # Convert job skills string to lowercase list
    job_set = {
        skill.strip().lower()
        for skill in job_skills.split(",")
        if skill.strip()
    }

    # Matched skills
    matched_skills = list(resume_set.intersection(job_set))

    # Missing skills
    missing_skills = list(job_set - resume_set)

    # Match percentage
    if len(job_set) == 0:
        match_percentage = 0
    else:
        match_percentage = round(
            (len(matched_skills) / len(job_set)) * 100,
            2
        )

    return {
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "match_percentage": match_percentage
    }