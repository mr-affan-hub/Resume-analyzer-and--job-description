import json
import google.generativeai as genai

from app.config import GEMINI_API_KEY

genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel("gemini-2.5-flash")


def analyze_resume(resume_text):

    prompt = f"""
You are an expert ATS Resume Analyzer.

Analyze this resume.

Return ONLY valid JSON in this format:

{{
    "score": 90,
    "skills": [],
    "missing_skills": [],
    "recommended_job": "",
    "strengths": [],
    "weaknesses": [],
    "suggestions": []
}}

Resume:

{resume_text}
"""

    response = model.generate_content(prompt)

    try:
        return json.loads(response.text)
    except Exception:
        return {
            "score": 0,
            "skills": [],
            "missing_skills": [],
            "recommended_job": "Unknown",
            "strengths": [],
            "weaknesses": [],
            "suggestions": [response.text]
        }