def extract_skills(text):
    skills_db = [
        "Python",
        "Java",
        "C",
        "C++",
        "SQL",
        "HTML",
        "CSS",
        "JavaScript",
        "React",
        "FastAPI",
        "Django",
        "Flask",
        "Machine Learning",
        "Deep Learning",
        "Data Analytics",
        "Power BI",
        "Excel",
        "Git",
        "GitHub",
        "AWS"
    ]

    found_skills = []

    for skill in skills_db:
        if skill.lower() in text.lower():
            found_skills.append(skill)

    return found_skills