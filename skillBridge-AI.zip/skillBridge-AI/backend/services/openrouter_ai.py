import requests

OPENROUTER_API_KEY = "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"

URL = "https://openrouter.ai/api/v1/chat/completions"


def analyze_resume(resume_text):

    prompt = f"""
You are an ATS Resume Expert.

Analyze this resume.

Return:
1. Resume Score
2. Strengths
3. Weaknesses
4. Missing Skills
5. Improvement Suggestions
6. Recommended Jobs

Resume:

{resume_text}
"""

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    data = {
        "model": "openai/gpt-4.1-mini",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    response = requests.post(
        URL,
        headers=headers,
        json=data
    )

    response.raise_for_status()

    return response.json()["choices"][0]["message"]["content"]