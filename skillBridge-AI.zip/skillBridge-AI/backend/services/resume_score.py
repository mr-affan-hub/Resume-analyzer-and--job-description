def calculate_resume_score(skills):
    score = 0

    score += min(len(skills) * 10, 60)

    if len(skills) >= 5:
        score += 20

    if len(skills) >= 8:
        score += 20

    return min(score, 100)