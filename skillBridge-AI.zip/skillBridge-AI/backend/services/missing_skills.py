def get_missing_skills(job_role, skills):

    skills = [skill.lower() for skill in skills]

    job_skills = {
        "Backend Developer": [
            "python",
            "fastapi",
            "sql",
            "git",
            "docker",
            "rest api"
        ],

        "Frontend Developer": [
            "html",
            "css",
            "javascript",
            "react",
            "typescript",
            "redux"
        ],

        "Data Analyst": [
            "python",
            "sql",
            "excel",
            "power bi",
            "pandas"
        ],

        "Machine Learning Engineer": [
            "python",
            "machine learning",
            "deep learning",
            "tensorflow",
            "pandas",
            "numpy"
        ],

        "Java Developer": [
            "java",
            "spring boot",
            "sql",
            "git"
        ]
    }

    required = job_skills.get(job_role, [])

    missing = []

    for skill in required:
        if skill not in skills:
            missing.append(skill.title())

    return missing
