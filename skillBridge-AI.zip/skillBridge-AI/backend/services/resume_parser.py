import PyPDF2
from docx import Document
from pathlib import Path


def extract_text(file_path):
    text = ""

    try:
        extension = Path(file_path).suffix.lower()

        if extension == ".pdf":
            with open(file_path, "rb") as file:
                reader = PyPDF2.PdfReader(file)

                for page in reader.pages:
                    page_text = page.extract_text()

                    if page_text:
                        text += page_text

        elif extension == ".docx":
            doc = Document(file_path)

            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"

        return text

    except Exception as e:
        print("Resume Parser Error:", e)
        return ""