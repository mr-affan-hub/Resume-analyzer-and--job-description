from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from models.job import Job
from schemas.job import JobCreate

router = APIRouter(
    prefix="/jobs",
    tags=["Jobs"]
)


@router.post("/add")
def add_job(
    job: JobCreate,
    db: Session = Depends(get_db)
):

    new_job = Job(
        title=job.title,
        company=job.company,
        location=job.location,
        skills=job.skills,
        salary=job.salary
    )

    db.add(new_job)
    db.commit()
    db.refresh(new_job)

    return {
        "message": "Job Added Successfully",
        "job": new_job
    }


@router.get("/")
def get_jobs(
    db: Session = Depends(get_db)
):

    return db.query(Job).all()