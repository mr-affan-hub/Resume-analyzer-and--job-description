from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.database import get_db
from models.resume import Resume
from services.dependencies import get_current_user

router = APIRouter(
    prefix="/dashboard",
    tags=["Dashboard"]
)


@router.get("/")
def dashboard(
    current_user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    total_resumes = db.query(Resume).filter(
        Resume.user_id == current_user
    ).count()

    average_score = db.query(
        func.avg(Resume.score)
    ).filter(
        Resume.user_id == current_user
    ).scalar()

    latest_resume = db.query(Resume).filter(
        Resume.user_id == current_user
    ).order_by(
        Resume.id.desc()
    ).first()

    return {
        "status": "success",
        "total_resumes": total_resumes,
        "average_score": round(average_score or 0, 2),
        "latest_resume": {
            "id": latest_resume.id,
            "filename": latest_resume.filename,
            "score": latest_resume.score,
            "recommended_job": latest_resume.recommended_job
        } if latest_resume else None
    }