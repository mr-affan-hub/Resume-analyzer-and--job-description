from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

print(">>> USER.PY LOADED <<<")

from schemas.user import UserCreate, UserLogin
from models.user import User
from app.database import get_db

from services.jwt_handler import create_access_token
from services.auth import hash_password, verify_password


router = APIRouter(
    prefix="/users",
    tags=["Users"]
)


# -----------------------------
# Health Check
# -----------------------------
@router.get("/")
def get_users():
    return {
        "message": "Users API is working!"
    }


# -----------------------------
# Register
# -----------------------------
@router.post("/register")
def register(
    user: UserCreate,
    db: Session = Depends(get_db)
):

    existing_user = db.query(User).filter(
        User.email == user.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    hashed_password = hash_password(user.password)

    new_user = User(
        name=user.name,
        email=user.email,
        password=hashed_password
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "message": "User Registered Successfully",
        "id": new_user.id,
        "name": new_user.name,
        "email": new_user.email
    }


# -----------------------------
# Login
# -----------------------------
@router.post("/login")
def login(
    user: UserLogin,
    db: Session = Depends(get_db)
):

    existing_user = db.query(User).filter(
        User.email == user.email
    ).first()

    if not existing_user:
        raise HTTPException(
            status_code=404,
            detail="Email not found"
        )

    if not verify_password(
        user.password,
        existing_user.password
    ):
        raise HTTPException(
            status_code=401,
            detail="Incorrect password"
        )

    token = create_access_token(
        {
            "sub": str(existing_user.id)
        }
    )

    return {
        "message": "Login Successful",
        "access_token": token,
        "token_type": "bearer",
        "id": existing_user.id,
        "name": existing_user.name,
        "email": existing_user.email
    }


# -----------------------------
# DEBUG - All Users
# -----------------------------
@router.get("/debug")
def debug_users(db: Session = Depends(get_db)):
    users = db.query(User).all()

    return [
        {
            "id": user.id,
            "name": user.name,
            "email": user.email
        }
        for user in users
    ]


# -----------------------------
# DEBUG - Raw Users
# -----------------------------
@router.get("/all")
def all_users(db: Session = Depends(get_db)):
    return db.query(User).all()