# backend/app/routers/resume.py

import json
import os
import shutil
import uuid
import requests
import re
from pathlib import Path
from fastapi import (
    APIRouter,
    UploadFile,
    File,
    HTTPException,
    Depends
)
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.database import get_db
from models.resume import Resume
from app.config import OPENROUTER_API_KEY
from services.resume_parser import extract_text
from services.details_extractor import extract_details
from services.skill_extractor import extract_skills
from services.dependencies import get_current_user
from models.user import User

router = APIRouter(
    prefix="/resume",
    tags=["Resume"]
)


# -----------------------------
# Upload Resume
# -----------------------------
@router.post("/upload")
async def upload_resume(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: int = Depends(get_current_user)
):
    extension = Path(file.filename).suffix.lower()

    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail="Only PDF and DOCX files allowed"
        )

    contents = await file.read()

    if len(contents) > MAX_FILE_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail=f"File too large. Max size is {MAX_FILE_SIZE_MB}MB"
        )

    if not contents:
        raise HTTPException(
            status_code=400,
            detail="Uploaded file is empty"
        )

    filename = f"{uuid.uuid4()}{extension}"
    file_path = UPLOAD_DIR / filename

    try:
        with open(file_path, "wb") as buffer:
            buffer.write(contents)

    except OSError as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to save file: {e}"
        )


    # -----------------------------
    # Extract Resume Text
    # -----------------------------
    text = extract_text(str(file_path))

    print("\n==============================")
    print("RESUME TEXT")
    print("==============================")
    print(text)


    # -----------------------------
    # Extract Details
    # -----------------------------
    details = extract_details(text)

    print("\nDETAILS")
    print(details)


    # -----------------------------
    # Extract Skills
    # -----------------------------
    skills = extract_skills(text)

    print("\nSKILLS")
    print(skills)


    # -----------------------------
    # Save Resume
    # -----------------------------
    resume = Resume(
        user_id=current_user,

        filename=filename,
        original_name=file.filename,
        filepath=str(file_path),

        name=details.get("name"),
        email=details.get("email"),
        phone=details.get("phone"),

        skills=",".join(skills)
    )


    db.add(resume)
    db.commit()
    db.refresh(resume)


    return {
        "message": "Resume uploaded successfully",
        "resume_id": resume.id,
        "filename": resume.filename,
        "name": resume.name,
        "email": resume.email,
        "phone": resume.phone,
        "skills": skills,
        "user_id": current_user.id
    }


# -----------------------------
# Get All Resumes
# -----------------------------

@router.get("/")
def get_resumes(db: Session = Depends(get_db)):
    return db.query(Resume).all()


# -----------------------------
# Download Resume
# -----------------------------

@router.get("/download/{resume_id}")
def download_resume(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(Resume.id == resume_id).first()

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    if not os.path.exists(resume.filepath):
        raise HTTPException(status_code=404, detail="File missing")

    return FileResponse(
        path=resume.filepath,
        filename=resume.original_name
    )


# -----------------------------
# Delete Resume
# -----------------------------

@router.delete("/{resume_id}")
def delete_resume(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(Resume.id == resume_id).first()

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    if os.path.exists(resume.filepath):
        os.remove(resume.filepath)

    db.delete(resume)
    db.commit()

    return {"message": "Resume deleted successfully"}


# -----------------------------
# Extract Resume Text
# -----------------------------

def extract_text(file_path: str) -> str:
    text = ""
    extension = Path(file_path).suffix.lower()

    try:
        if extension == ".pdf":
            import PyPDF2

            reader = PyPDF2.PdfReader(file_path)
            for page in reader.pages:
                content = page.extract_text()
                if content:
                    text += content

        elif extension == ".docx":
            from docx import Document

            doc = Document(file_path)
            for paragraph in doc.paragraphs:
                text += paragraph.text + "\n"

    except Exception as e:
        print("Text extraction error:", e)

    return text


# -----------------------------
# Resume Analyze
# -----------------------------

@router.post("/analyze/{resume_id}")
def analyze_resume(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(Resume.id == resume_id).first()

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    resume_text = extract_text(resume.filepath)

    if not resume_text:
        raise HTTPException(status_code=400, detail="Unable to read resume")

    # Temporary AI Analysis (placeholder until real AI integration)
    analysis = {
        "score": 80,
        "feedback": "Resume has good structure. Improve projects and skills section.",
        "suggestions": [
            "Add more technical projects",
            "Mention measurable achievements",
            "Improve summary section"
        ],
        "strengths": [
            "Education details",
            "Technical skills"
        ],
        "weaknesses": [
            "Less project explanation",
            "Need more keywords"
        ]
    }

    # NOTE: use json.dumps instead of str() so these fields are valid
    # JSON when read back (str(list) produces single-quoted Python repr,
    # which json.loads() cannot parse).
    resume.ai_score = analysis["score"]
    resume.ai_feedback = analysis["feedback"]
    resume.ai_suggestions = json.dumps(analysis["suggestions"])
    resume.strengths = json.dumps(analysis["strengths"])
    resume.weaknesses = json.dumps(analysis["weaknesses"])

    db.commit()
    db.refresh(resume)

    return {
        "message": "Resume analyzed successfully",
        "analysis": analysis
    }
 
 # -----------------------------
# Gemini Resume Analysis
# -----------------------------

@router.post("/gemini/{resume_id}")
def gemini_resume_analysis(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(
        Resume.id == resume_id
    ).first()

    if not resume:
        raise HTTPException(
            status_code=404,
            detail="Resume not found"
        )

    text = extract_text(resume.filepath)

    if not text:
        raise HTTPException(
            status_code=400,
            detail="Unable to read resume"
        )

    result = gemini_analyze(text)

    # Save AI result in database
    if "error" not in result:
        resume.ai_score = result["score"]
        resume.ai_feedback = result["feedback"]
        resume.ai_suggestions = json.dumps(result["suggestions"])
        resume.strengths = json.dumps(result["strengths"])
        resume.weaknesses = json.dumps(result["weaknesses"])

        db.commit()
        db.refresh(resume)

    return {
        "resume_id": resume_id,
        "analysis": result
    }

# -----------------------------
# Get Single Resume
# -----------------------------

@router.get("/{resume_id}")
def get_resume(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(Resume.id == resume_id).first()

    if not resume:
        raise HTTPException(status_code=404, detail="Resume not found")

    return resume

# -----------------------------
# Skill Gap Detection Function
# -----------------------------
def detect_skill_gap(resume_skills, required_skills):
    resume_set = {
        skill.strip().lower()
        for skill in resume_skills
        if skill.strip()
    }

    required_set = {
        skill.strip().lower()
        for skill in required_skills
        if skill.strip()
    }

    return sorted(list(required_set - resume_set))


# -----------------------------
# Skill Gap Detection API
# -----------------------------
@router.post("/skill-gap/{resume_id}")
def skill_gap(
    resume_id: int,
    db: Session = Depends(get_db)
):
    resume = db.query(Resume).filter(
        Resume.id == resume_id
    ).first()

    if resume is None:
        raise HTTPException(
            status_code=404,
            detail="Resume not found"
        )

    resume_skills = []

    if resume.skills:
        resume_skills = [
            skill.strip()
            for skill in resume.skills.split(",")
            if skill.strip()
        ]

    required_skills = [
        "python",
        "java",
        "sql",
        "html",
        "css",
        "javascript",
        "react",
        "nodejs",
        "mongodb",
        "git"
    ]

    missing_skills = detect_skill_gap(
        resume_skills,
        required_skills
    )

    return {
        "resume_id": resume.id,
        "resume_skills": resume_skills,
        "missing_skills": missing_skills
    }

# -----------------------------
# Gemini AI Integration
# -----------------------------



def gemini_analyze(text: str) -> dict:
    try:
        from app.config import OPENROUTER_API_KEY
    except ImportError:
        return {
            "error": "OpenRouter API key not found"
        }

    if not OPENROUTER_API_KEY:
        return {
            "error": "OpenRouter API key is empty"
        }

    url = "https://openrouter.ai/api/v1/chat/completions"

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json",
        "HTTP-Referer": "http://localhost:5173",
        "X-Title": "SkillBridge-AI"
    }

    prompt = f"""
Analyze this resume.

Return ONLY in this format:

1. Resume Score: <number>/100

2. Feedback:
<paragraph>

3. Suggestions:
- suggestion 1
- suggestion 2
- suggestion 3

4. Strengths:
- strength 1
- strength 2
- strength 3

5. Weaknesses:
- weakness 1
- weakness 2
- weakness 3

Resume:
{text}
"""

    payload = {
        "model": "google/gemma-3-27b-it",
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ]
    }

    try:
        response = requests.post(
            url,
            headers=headers,
            json=payload,
            timeout=60
        )

        print("Status:", response.status_code)
        print("Response:", response.text)

        response.raise_for_status()

        data = response.json()

        feedback = data["choices"][0]["message"]["content"]

        # -------------------------
        # Extract Score
        # -------------------------
        score_match = re.search(
            r'(\d{1,3})\s*/\s*100',
            feedback,
            re.IGNORECASE
        )

        score = int(score_match.group(1)) if score_match else 0

        # -------------------------
        # Helper Function
        # -------------------------
        def extract_list(section):

            pattern = rf"{section}:?(.*?)(?=\n\s*\d+\.\s|\Z)"

            match = re.search(
                pattern,
                feedback,
                re.DOTALL | re.IGNORECASE
            )

            if not match:
                return []

            text = match.group(1)

            items = re.findall(
                r'[-*]\s*(.+)',
                text
            )

            return [i.strip() for i in items]

        # -------------------------
        # Extract Feedback
        # -------------------------
        feedback_match = re.search(
            r'Feedback:?(.*?)(?=\n\s*3\.)',
            feedback,
            re.DOTALL | re.IGNORECASE
        )

        clean_feedback = (
            feedback_match.group(1).strip()
            if feedback_match
            else feedback
        )

        suggestions = extract_list("Suggestions")
        strengths = extract_list("Strengths")
        weaknesses = extract_list("Weaknesses")

        return {
            "score": score,
            "feedback": clean_feedback,
            "suggestions": suggestions,
            "strengths": strengths,
            "weaknesses": weaknesses
        }

    except Exception as e:
        return {
            "error": str(e)
        }