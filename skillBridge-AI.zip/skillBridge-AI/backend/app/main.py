from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import APP_NAME, VERSION
from app.database import Base, engine

from models.user import User
from models.resume import Resume
from models.job import Job

from routers.user import router as user_router
from routers.resume import router as resume_router
from routers.dashboard import router as dashboard_router
from routers.job import router as job_router


# Create database tables
Base.metadata.create_all(bind=engine)


app = FastAPI(
    title=APP_NAME,
    version=VERSION
)


# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5177",
        "http://127.0.0.1:5177",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Include Routers
app.include_router(user_router)
app.include_router(resume_router)
app.include_router(dashboard_router)
app.include_router(job_router)


@app.get("/")
def home():
    return {
        "message": "Welcome to SkillBridge AI"
    }