# backend/app/config.py

APP_NAME = "SkillBridge-AI"
VERSION = "1.0.0"

DATABASE_URL = "sqlite:///./skillbridge.db"

# OpenRouter API Key
OPENROUTER_API_KEY = "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"