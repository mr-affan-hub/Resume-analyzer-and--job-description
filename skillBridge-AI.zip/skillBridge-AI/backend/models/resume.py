from sqlalchemy import Column, Integer, String, Text, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


class Resume(Base):

    __tablename__ = "resumes"

    id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    # User Connection
    user_id = Column(
        Integer,
        ForeignKey("users.id"),
        nullable=True
    )

    # File Details
    filename = Column(
        String,
        nullable=False
    )

    original_name = Column(
        String,
        nullable=False
    )

    filepath = Column(
        String,
        nullable=False
    )

    # Resume Details
    name = Column(String)
    email = Column(String)
    phone = Column(String)

    # Extracted Skills
    skills = Column(Text)

    # Resume Score
    score = Column(Integer)

    recommended_job = Column(String)

    missing_skills = Column(Text)

    # AI Analysis
    ai_score = Column(Integer)

    ai_feedback = Column(Text)

    ai_suggestions = Column(Text)

    strengths = Column(Text)

    weaknesses = Column(Text)

    # Relationship
    user = relationship(
        "User",
        back_populates="resumes"
    )