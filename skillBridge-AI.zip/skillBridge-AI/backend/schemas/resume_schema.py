from pydantic import BaseModel

class ResumeResponse(BaseModel):
    filename: str
    score: int
    recommended_job: str

    class Config:
        from_attributes = True