from pydantic import BaseModel


class JobCreate(BaseModel):

    title: str

    company: str

    location: str

    skills: str

    salary: str